using namespace vex;

extern brain Brain;

// VEXcode devices
extern controller Controller1;
extern motor Front_Left;
extern motor Front_Right;
extern motor Back_Right;
extern motor Back_Left;
extern motor Catapult_Motor;
extern motor Roller_Motor;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );